/*
 * Copyright 2020, Data61, CSIRO (ABN 41 687 119 230)
 *
 * SPDX-License-Identifier: BSD-2-Clause
 */

#pragma once

#define SEL4_WORD_IS_UINT64
#define SEL4_INT64_IS_LONG

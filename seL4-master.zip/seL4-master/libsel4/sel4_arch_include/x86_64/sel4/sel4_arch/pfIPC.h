/*
 * Copyright 2020, Data61, CSIRO (ABN 41 687 119 230)
 *
 * SPDX-License-Identifier: BSD-2-Clause
 */

#ifndef __LIBSEL4_SEL4_SEL4_ARCH_PFIPC_H_
#define __LIBSEL4_SEL4_SEL4_ARCH_PFIPC_H_

#endif /* __LIBSEL4_SEL4_SEL4_ARCH_PFIPC_H_ */

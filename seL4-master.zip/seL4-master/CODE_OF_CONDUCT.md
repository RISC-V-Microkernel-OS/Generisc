<!--
     Copyright 2020, Data61, CSIRO (ABN 41 687 119 230)

     SPDX-License-Identifier: CC-BY-SA-4.0
-->

# Code of Conduct

This repository and interactions with it fall under the [seL4 Code of Conduct][1] available from the [seL4 website][2].

[1]: https://docs.sel4.systems/processes/conduct.html
[2]: https://sel4.systems
